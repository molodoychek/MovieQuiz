import UIKit

protocol MovieQuizViewControllerProtocol: AnyObject {
    func show(quiz step: QuizStepViewModel)
    func showLoadingIndicator()
    func hideLoadingIndicator()
    func showNetworkError(message: String)
    func showFinalResults()
    func highlightImageBorder(isCorrect: Bool)
    func removeImageBorder()
    func showNextQuestion()
}
