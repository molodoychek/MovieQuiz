import UIKit


final class MovieQuizPresenter: MovieQuizPresenterProtocol, QuestionFactoryDelegate{
    
    // MARK: - Properties
    private let questionsAmount: Int = 10
    private var currentQuestionIndex = 0
    private var correctAnswers = 0
    private var isButtonEnabled = true
    
    // Шаг 7: QuestionFactory теперь в презентере
    private var questionFactory: QuestionFactoryProtocol?
    // Шаг 8: StatisticService в презентере
    private var statisticService: StatisticServiceProtocol!
    
    weak var viewController: MovieQuizViewControllerProtocol?
    var currentQuestion: QuizQuestion?
    
    var isLastQuestion: Bool {
        currentQuestionIndex == questionsAmount - 1
    }
    
    private var questionNumberText: String {
        "\(currentQuestionIndex + 1)/\(questionsAmount)"
    }
    
    // MARK: - Initializer
    init(viewController: MovieQuizViewControllerProtocol? = nil) {
        self.viewController = viewController
        self.statisticService = StatisticService()
    }
    
    // MARK: - Public Methods
    
    func setupQuestionFactory(delegate: QuestionFactoryDelegate) {
        let moviesLoader = MoviesLoader()
        questionFactory = QuestionFactory(moviesLoader: moviesLoader, delegate: delegate)
    }
    
    func startLoadingQuestions() {
        let moviesLoader = MoviesLoader()
        questionFactory = QuestionFactory(moviesLoader: moviesLoader, delegate: self)
        questionFactory?.loadData()
    }
    
    func requestNextQuestion() {
        questionFactory?.requestNextQuestion()
    }
    
    func yesButtonClicked() {
        handleAnswer(isYes: true)
    }
    
    func noButtonClicked() {
        handleAnswer(isYes: false)
    }
    
    func convert(model: QuizQuestion) -> QuizStepViewModel {
        return QuizStepViewModel(
            image: UIImage(data: model.image) ?? UIImage(),
            question: model.text,
            questionNumber: questionNumberText
        )
    }
    
    func restartGame() {
        currentQuestionIndex = 0
        correctAnswers = 0
        currentQuestion = nil
        isButtonEnabled = true
        requestNextQuestion()
    }
    
    func proceedToNextQuestion() {
        currentQuestionIndex += 1
    }
    
    func makeResultsMessage() -> String {
        // Сохраняем результат
        statisticService.store(correct: correctAnswers, total: questionsAmount)
        
        let bestGame = statisticService.bestGame
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.YY HH:mm"
        let bestGameDate = dateFormatter.string(from: bestGame.date)
        
        return """
        Ваш результат: \(correctAnswers)/\(questionsAmount)
        Количество сыгранных квизов: \(statisticService.gamesCount)
        Рекорд: \(bestGame.correct)/\(bestGame.total) (\(bestGameDate))
        Средняя точность: \(String(format: "%.2f", statisticService.totalAccuracy))%
        """
    }
    
    // MARK: - Private Methods
    
    private func handleAnswer(isYes: Bool) {
        guard isButtonEnabled, let currentQuestion = currentQuestion else { return }
        
        let isCorrect = isYes == currentQuestion.correctAnswer
        if isCorrect {
            correctAnswers += 1
        }
        
        isButtonEnabled = false
        viewController?.highlightImageBorder(isCorrect: isCorrect)
        
        // Шаг 10: Асинхронный код в презентере
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.showNextQuestionOrResults()
        }
    }
    
    private func showNextQuestionOrResults() {
        isButtonEnabled = true
        viewController?.removeImageBorder()
        
        if isLastQuestion {
            viewController?.showFinalResults()
        } else {
            proceedToNextQuestion()
            viewController?.showNextQuestion()
        }
    }
}
